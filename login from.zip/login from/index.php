<?php
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    // echo $name.' '.$email.' '.$mobile.'  '.$password;
    $input_error=array();
    if(empty($name)){
     $input_error['name']="name field is required";
    }
    if(empty($email)){
        $input_error['email']="email field is required";
       }
       if(empty($mobile)){
        $input_error['mobile']="mobile field is required";
       }
       if(empty($password)){
        $input_error['password']="password field is required";
       }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
     <label for="name">name</label><br>
     <input type="text" name="name" id="name" value="<?php if(isset($name)){echo $name;}?>"><br>
     <small style="color:red;"><?php if(isset($input_error['name'])){echo $input_error['name'];}?></small><br>
     <label for="email">email</label><br>
     <input type="email" name="email" id="email" value="<?php if(isset($email)){echo $email;}?>"><br>
     <small style="color:red;"><?php if(isset($input_error['email'])){echo $input_error['email'];}?></small><br>
     <label for="mobile">mobile</label><br>
     <input type="tel" name="mobile" id="mobile" value="<?php if(isset($mobile)){echo $mobile;}?>"><br>
     <small style="color:red;"><?php if(isset($input_error['mobile'])){echo $input_error['mobile'];}?></small><br>
     <label for="password">password</label><br>
     <input type="password" name="password" id="password" value="<?php if(isset($password)){echo $password;}?>"><br>
     <small style="color:red;"><?php if(isset($input_error['password'])){echo $input_error['password'];}?></small><br>
     <input type="submit" value="submit" name="submit" >
    </form>
</body>
</html>